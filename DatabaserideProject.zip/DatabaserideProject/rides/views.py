from django.shortcuts import render
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status
from .models import Rider, Driver, Ride, Acceptance
from .serializers import RiderSerializer, DriverSerializer, RideSerializer, AcceptanceSerializer


@api_view(['POST'])
def request_ride(request):
    """Endpoint to request a new ride."""
    serializer = RideSerializer(data=request.data)
    if serializer.is_valid():
        serializer.save()
        return Response(serializer.data, status=status.HTTP_201_CREATED)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


@api_view(['POST'])
def accept_ride(request):
    """Endpoint for a driver to accept a ride."""
    serializer = AcceptanceSerializer(data=request.data)
    if serializer.is_valid():
        serializer.save()
        return Response(serializer.data, status=status.HTTP_201_CREATED)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


@api_view(['GET'])
def ride_details(request, ride_id):
    """Endpoint to retrieve ride details."""
    try:
        ride = Ride.objects.get(rideid=ride_id)
        serializer = RideSerializer(ride)
        return Response(serializer.data)
    except Ride.DoesNotExist:
        return Response({"error": "Ride not found"}, status=status.HTTP_404_NOT_FOUND)


@api_view(['POST'])
def complete_ride(request, ride_id):
    """Endpoint to complete a ride and make payment."""
    try:
        ride = Ride.objects.get(rideid=ride_id)
        ride.status = 'Completed'
        ride.save()
        # Mock payment logic
        payment_status = 'Success' if request.data.get('payment') else 'Failure'
        return Response({"ride_id": ride_id, "payment_status": payment_status})
    except Ride.DoesNotExist:
        return Response({"error": "Ride not found"}, status=status.HTTP_404_NOT_FOUND)
