from django.urls import path
from .views import request_ride, accept_ride, ride_details, complete_ride

urlpatterns = [
    path('ride/request/', request_ride, name='request_ride'),
    path('ride/accept/', accept_ride, name='accept_ride'),
    path('ride/<int:ride_id>/', ride_details, name='ride_details'),
    path('ride/complete/<int:ride_id>/', complete_ride, name='complete_ride'),
]
