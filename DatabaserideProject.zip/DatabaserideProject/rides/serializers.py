from rest_framework import serializers
from .models import Rider, Driver, Ride, Acceptance

class RiderSerializer(serializers.ModelSerializer):
    class Meta:
        model = Rider
        fields = '__all__'


class DriverSerializer(serializers.ModelSerializer):
    class Meta:
        model = Driver
        fields = '__all__'


class RideSerializer(serializers.ModelSerializer):
    class Meta:
        model = Ride
        fields = '__all__'


class AcceptanceSerializer(serializers.ModelSerializer):
    class Meta:
        model = Acceptance
        fields = '__all__'
