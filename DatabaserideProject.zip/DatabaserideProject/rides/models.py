from django.db import models
from django.contrib.gis.db import models as gis_models

class Rider(models.Model):
    riderid = models.AutoField(primary_key=True)
    preferredpaymentmethod = models.TextField(null=True, blank=True)
    rating = models.FloatField(null=True, blank=True)

    class Meta:
        db_table = 'rider'
        managed = False  # This ensures Django doesn't recreate or manage the table


class Driver(models.Model):
    driverid = models.AutoField(primary_key=True)
    vehicleinfo = models.TextField(null=True, blank=True)
    licenseinfo = models.TextField(null=True, blank=True)
    availabilitystatus = models.TextField(null=True, blank=True)
    rating = models.FloatField(null=True, blank=True)
    location = gis_models.PointField(srid=4326, null=True, blank=True)

    class Meta:
        db_table = 'driver'
        managed = False


class Ride(models.Model):
    rideid = models.AutoField(primary_key=True)
    riderid = models.IntegerField()
    driverid = models.IntegerField()
    pickuplocation = models.CharField(max_length=255)
    dropofflocation = models.CharField(max_length=255)
    status = models.CharField(max_length=50)
    starttime = models.DateTimeField()
    endtime = models.DateTimeField()

    class Meta:
        db_table = 'ride'
        managed = False


class Acceptance(models.Model):
    acceptanceid = models.AutoField(primary_key=True)
    driverid = models.IntegerField(null=True, blank=True)
    rideid = models.IntegerField(null=True, blank=True)
    acceptancetime = models.DateTimeField(null=True, blank=True)
    status = models.TextField(null=True, blank=True)

    class Meta:
        db_table = 'acceptance'
        managed = False
